# 40K Field Companion PWA

Installable Progressive Web App version of the Necrons-first 40K companion.

## Included
- Android/home-screen install support via Web App Manifest
- Standalone/full-screen PWA mode
- Offline app-shell caching
- Cached BSData Necron catalogue and MFM data after first successful load
- Necron unit stats, points, weapons, abilities, leader relationships
- Multi-detachment selection with a 3 DP cap
- Detachment-synergy tags
- Build, Battle and Search modes

## Run locally
```bash
npm install
npm run dev
```

For PWA installation, serve it over HTTPS (or localhost during development).

## Build
```bash
npm run build
npm run preview
```
